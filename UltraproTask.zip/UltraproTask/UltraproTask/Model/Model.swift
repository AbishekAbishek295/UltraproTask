//
//  Model.swift
//  UltraproTask
//
//  Created by abishek m on 05/10/24.
//

import Foundation

struct Todo: Codable {
    let title: String
    let completed: Bool
}

struct Company: Codable {
    let name: String
    let industry: String
}
