//
//  ViewController.swift
//  UltraproTask
//
//  Created by abishek m on 05/10/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var todos: [Todo] = []
    var companies: [Company] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.register(UINib(nibName: "TodoTableViewCell", bundle: nil), forCellReuseIdentifier: "TodoCell")
        tableView.register(UINib(nibName: "ComapanyTableViewCell", bundle: nil), forCellReuseIdentifier: "CompanyCell")
        
        fetchTodos()
        setupRefreshControl()
    }
    

    func fetchTodos() {
        guard let url = URL(string: "https://json-placeholder.mock.beeceptor.com/todos") else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.showError(error: error)
                }
                return
            }
            
            guard let data = data else { return }
            
            do {
                let decodedTodos = try JSONDecoder().decode([Todo].self, from: data)
                self.todos = decodedTodos
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                    self.fetchCompanies()
                }
            } catch {
                DispatchQueue.main.async {
                    self.showError(error: error)
                }
            }
        }.resume()
    }
    

    func fetchCompanies() {
        guard let url = URL(string: "https://fake-json-api.mock.beeceptor.com/companies") else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.showError(error: error)
                }
                return
            }
            
            guard let data = data else { return }
            
            do {
                let decodedCompanies = try JSONDecoder().decode([Company].self, from: data)
                self.companies = decodedCompanies
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            } catch {
                DispatchQueue.main.async {
                    self.showError(error: error)
                }
            }
        }.resume()
    }
    

    func showError(error: Error) {
        let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    

    func setupRefreshControl() {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(refreshData), for: .valueChanged)
        tableView.refreshControl = refreshControl
    }
    
    @objc func refreshData() {
        fetchTodos()
        tableView.refreshControl?.endRefreshing()
    }
}


//TableView

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == 0 ? todos.count : companies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
         
            let cell = tableView.dequeueReusableCell(withIdentifier: "TodoCell", for: indexPath) as! TodoTableViewCell
            let todo = todos[indexPath.row]
            
            cell.title.text = "TODO Title: \(todo.title)"
            cell.status.text = todo.completed ? "TODO Status: Completed" : "TODO Status: Not Completed"
            
            return cell
        } else{

            let cell = tableView.dequeueReusableCell(withIdentifier: "CompanyCell", for: indexPath) as! ComapanyTableViewCell
            let company = companies[indexPath.row]
            
            cell.name?.text = "Company Name: \(company.name)"
            cell.industry?.text = "Company Industry: \(company.industry)"
            
            return cell
        }
        
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if section == 0 {
            return "TODOs"
        }else{
            return "Companies"
        }
    }
    
}
